/**
 * 
 */
package com.abc.test;

/**
 * @author ajay.ab.singh
 *
 */
public interface ITestMemory {
	// reproduce memory issue
    public void createMemeotryissue();
    
    // solve the memory issue
    public void solveMemoeryIssue();
}
