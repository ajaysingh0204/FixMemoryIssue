/**
 * 
 */
package com.abc.test;

/**
 * @author ajay.ab.singh
 *
 */
public class RunMyMemoryTest {

	/**
	 * 
	 */
	public RunMyMemoryTest() {
		// TODO Auto-generated constructor stub
	}

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		try {
			// Occurred memory-leaks
			TestMyMemory createMemoryIssue = new TestMyMemory();
			createMemoryIssue.createMemeotryissue();

			// solve memory-leaks issue
			FixMemoryIssue fixMemoryIssue = new FixMemoryIssue();
			fixMemoryIssue.solveMemoeryIssue();
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
	}

}
