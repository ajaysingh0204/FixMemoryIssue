package com.abc.test;

import java.util.ArrayList;
import java.util.Random;

public class FixMemoryIssue implements ITestMemory {

	public FixMemoryIssue() {
		// TODO Auto-generated constructor stub
	}

	@Override
	public void createMemeotryissue() {
		// TODO Auto-generated method stub

	}
	/**The ArrayList isn�t referenced by a static variable. Instead, it�s a local variable that gets created, used and then discarded.
	 * Run the test and analyze the JVM with our profiler to verify
	 */
	@Override
	public void solveMemoeryIssue() {
		addElementsToTheList();
		System.gc();
		try {
			Thread.sleep(10000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} // to allow GC do its job

	}

	private void addElementsToTheList() {
		Random random = new Random();
		ArrayList<Double> list = new ArrayList<Double>(1000000000);
		for (int i = 0; i < 1000000000; i++) {
			list.add(random.nextDouble());
		}
	}
}
