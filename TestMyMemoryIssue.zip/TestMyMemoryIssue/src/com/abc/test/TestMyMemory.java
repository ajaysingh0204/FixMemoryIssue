package com.abc.test;

import java.util.ArrayList;
import java.util.Random;

public class TestMyMemory implements ITestMemory {
	private Random random = new Random();
	public static final ArrayList<Double> list = new ArrayList<Double>(1000000000);
	/**
	 * created ArrayList as a final static field � which will never be collected by the JVM Garbage Collector during the lifetime of the JVM process
	 * even after the calculations.Also invoked Thread.sleep(10000) to allow the GC to perform a full collection 
	 * and try to reclaim everything that can be reclaimed.
	 * Run the test and analyze the JVM with our profiler to verify
	 */
	@Override
	public void createMemeotryissue() {
		for (int i = 0; i < 1000000000; i++) {
	        list.add(random.nextDouble());
	    }
	    
	    System.gc();
	    try {
			Thread.sleep(10000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} // to allow GC do its job

	}
	
	/**
	 * 
	 * 
	 * 
	 */
	@Override
	public void solveMemoeryIssue() {
		// TODO Auto-generated method stub

	}	


}
